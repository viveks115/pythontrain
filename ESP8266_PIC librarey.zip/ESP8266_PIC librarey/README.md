# ESP8266_PIC
C library for interfacing the ESP8266 Wi-Fi module with a PIC microcontroller

This is a work in progress. I'm using the XC8 compiler.
